Mass Effect Vector Pack by Karly "Karlika" Rosen.
All Emblems and logos are copyrighted by BioWare/EA Games.
Use of this vector pack is strictly for Fan and Non-Commercial Uses ONLY.
If used, please give credit. Thank you, and Enjoy!

This Pack Contains AI, EPS, SVG and Preview JPG of:
-Mass Effect Title Logo
-N7 Emblem
-SR1 Emblem
-SR2 Emblem
-Normandy Emblem
-Cerberus Logo
-System Alliance Emblem
-Spectre Emblem
-Paragon Emblem
-Renegade Emblem.

*To whom it may concern: If you are a user/contributor to the Mass Effect Wiki, 
I do give my permission to use these, so long as you do credit them properly.